(() => {
  // A dedicated effects context: neither BGM volume nor BGM mute controls it.
  const monitor = document.createElement('output');
  monitor.id = 'gardenTapAudioStatus';
  monitor.hidden = true;
  monitor.dataset.started = '0';
  monitor.dataset.ended = '0';
  document.body.append(monitor);
  let context, buffer, decoding, active, pending = false;
  let status = '按鍵聲準備中，第一次點按會啟動音效。';
  const setStatus = text => { status = text; monitor.textContent = text; };
  const bytes = fetch(new URL('assets/assets/audio/button_tap.wav?v=tap-audio2', document.baseURI))
    .then(response => { if (!response.ok) throw Error('audio asset'); return response.arrayBuffer(); });
  // Handle preload rejection immediately; allow a useful status instead of a silent failure.
  bytes.catch(() => setStatus('按鍵音檔未能載入，請重新整理再試。'));
  function start() {
    if (!pending || !buffer || context?.state !== 'running') return;
    pending = false;
    try {
      if (active) { active.onended = null; active.stop(); }
      const source = context.createBufferSource(), gain = context.createGain();
      source.buffer = buffer;
      gain.gain.value = .6;
      source.connect(gain); gain.connect(context.destination);
      source.onended = () => {
        monitor.dataset.ended = String(Number(monitor.dataset.ended) + 1);
        if (active === source) active = null;
        source.disconnect(); gain.disconnect();
        setStatus('按鍵聲播放完成。');
      };
      source.start(); active = source;
      monitor.dataset.started = String(Number(monitor.dataset.started) + 1);
      setStatus('按鍵聲播放中。');
    } catch { setStatus('按鍵聲未能播放，請再按「試聽按鍵聲」。'); }
  }
  function unlock() {
    try {
      if (!context) {
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        if (!AudioContext) { setStatus('瀏覽器未支援按鍵音效，請改用 Chrome 或 Safari。'); return; }
        context = new AudioContext();
        context.onstatechange = () => { monitor.dataset.context = context.state; start(); };
      }
      monitor.dataset.context = context.state;
      if (context.state !== 'running') context.resume().then(start).catch(() =>
        setStatus('瀏覽器暫停音效，請再按「試聽按鍵聲」。'));
      if (!decoding) decoding = bytes.then(data => context.decodeAudioData(data.slice(0)))
        .then(decoded => { buffer = decoded; monitor.dataset.loaded = 'true'; start(); })
        .catch(() => setStatus('按鍵音檔未能載入，請重新整理再試。'));
    } catch { setStatus('未能啟動音效，請再按「試聽按鍵聲」。'); }
  }
  document.addEventListener('pointerdown', unlock, {capture:true,passive:true});
  document.addEventListener('touchend', unlock, {capture:true,passive:true});
  document.addEventListener('keydown', event => {
    if (event.key === 'Enter' || event.key === ' ') unlock();
  }, true);
  window.gardenPlayTap = () => { pending = true; unlock(); start(); };
  window.gardenTapStatus = () => status;
})();
