(() => {

  let listening;
  window.gardenCancelListening = () => listening?.abort();
  window.gardenStopListening = () => listening?.stop();
  window.gardenListenSpelling = () => new Promise(resolve => {
    const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!Recognition) return resolve(JSON.stringify({error:'呢個瀏覽器未支援串字收音。請用 Chrome 或 Safari 打開試玩頁，亦可打字回答。'}));
    const recognition = listening = new Recognition();
    recognition.lang = 'en-US';
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.maxAlternatives = 5;
    let done = false, segments = [], timer;
    const alternatives = () => {
      let candidates = [''];
      for (const segment of segments.filter(Boolean)) {
        candidates = candidates.flatMap(prefix => segment.map(item => (prefix+' '+item.transcript).trim())).slice(0,5);
      }
      return candidates.filter(Boolean).map(text => ({text}));
    };
    const finish = data => {
      if (done) return;
      done = true; clearTimeout(timer); listening = null;
      resolve(JSON.stringify(data));
    };
    recognition.onresult = event => {
      segments = Array.from(event.results).map(result => Array.from(result));
    };
    recognition.onerror = event => {
      const messages = {
        'not-allowed':'咪高峰或語音辨識權限未開啟。請喺瀏覽器允許咪高峰，再試一次。',
        'service-not-allowed':'呢個瀏覽器未允許語音辨識服務。請用 Chrome 或 Safari 開啟同一試玩頁再試。',
        'audio-capture':'收唔到咪高峰聲音。請檢查咪高峰是否被其他程式佔用，或者裝置是否選啱。',
        'network':'瀏覽器連唔到語音辨識服務，唔係小朋友串錯。請用 Chrome 或 Safari 開啟試玩頁，並確認網絡可用。',
        'no-speech':'未收到說話聲音。靠近咪高峰逐個字母讀，再按完成串字。',
        'aborted':'已停止收音；未提交答案，唔計答錯。',
        'language-not-supported':'瀏覽器未支援英文辨識，請改用其他瀏覽器或打字。'
      };
      finish({error:messages[event.error] || '語音辨識服務未能完成，請改用其他瀏覽器或打字；唔計答錯。'});
    };
    recognition.onend = () => {
      const found = alternatives();
      finish(found.length ? {alternatives:found} : {error:'未收到可用答案；可以再試或打字，唔計答錯。'});
    };
    timer = setTimeout(() => {
      recognition.stop();
      const found = alternatives();
      finish(found.length ? {alternatives:found} : {error:'今次收音時間已到，未收到答案；可以再試，唔計答錯。'});
    },45000);
    try {recognition.start();} catch {
      finish({error:'咪高峰未能開啟，請檢查瀏覽器權限或改用打字回答。'});
    }
  });
  let library;
  function loadOCR() {
    if (window.Tesseract) return Promise.resolve(window.Tesseract);
    if (!library) library = new Promise((resolve,reject) => {
      const script = document.createElement('script');script.src='https://cdn.jsdelivr.net/npm/tesseract.js@6.0.1/dist/tesseract.min.js';
      script.onload=()=>resolve(window.Tesseract);script.onerror=()=>{library=null;script.remove();reject(new Error('首次辨識需要網絡載入引擎，請連線後再試。'));};document.head.append(script);
    });
    return library;
  }
  window.gardenScanWords = () => new Promise(resolve => {
    const input = document.createElement('input');input.type='file';input.accept='image/*';
    const finish = data => resolve(JSON.stringify(data));
    input.oncancel=()=>finish({cancelled:true});
    input.onchange=async()=> {
      if (!input.files[0]) return finish({cancelled:true});
      const url=URL.createObjectURL(input.files[0]);const image=new Image();
      image.onerror=()=>{URL.revokeObjectURL(url);finish({error:'相片未能開啟，請用 JPG／PNG 或相片截圖。'});};
      image.onload=()=>showCrop(image,url,finish);image.src=url;
    };
    input.click();
  });
  function showCrop(image,url,finish) {
    const overlay=document.createElement('div');overlay.setAttribute('role','dialog');overlay.setAttribute('aria-label','裁切生字相片');
    Object.assign(overlay.style,{position:'fixed',inset:'0',zIndex:'99999',background:'#fff9ed',overflow:'auto',padding:'20px',fontFamily:'sans-serif',boxSizing:'border-box'});
    const title=document.createElement('h2');title.textContent='框住英文生字嗰一欄';
    const help=document.createElement('p');help.textContent='拖拉框選，避開姓名、標題和中文。相片在瀏覽器處理，不會上傳；辨識後仍要逐字核對。';
    const canvas=document.createElement('canvas');canvas.style.cssText='display:block;max-width:100%;height:auto;touch-action:none;margin:12px auto';
    const controls=document.createElement('div');controls.style.cssText='display:flex;gap:12px;flex-wrap:wrap';
    const status=document.createElement('p');status.setAttribute('role','status');
    function button(label,action){const b=document.createElement('button');b.textContent=label;b.style.cssText='padding:14px 18px;border-radius:18px;border:1px solid #a494c8;background:#ece3ff;font-size:18px';b.onclick=action;controls.append(b);return b;}
    let source=document.createElement('canvas');source.width=image.naturalWidth;source.height=image.naturalHeight;source.getContext('2d').drawImage(image,0,0);
    let selection={x:0,y:0,w:source.width,h:source.height},start;
    function redraw(){const scale=Math.min(1,720/source.width,850/source.height);canvas.width=Math.round(source.width*scale);canvas.height=Math.round(source.height*scale);const ctx=canvas.getContext('2d');ctx.drawImage(source,0,0,canvas.width,canvas.height);ctx.strokeStyle='#995ac6';ctx.lineWidth=3;ctx.strokeRect(selection.x*scale,selection.y*scale,selection.w*scale,selection.h*scale);}
    function point(e){const r=canvas.getBoundingClientRect();return {x:Math.max(0,Math.min(source.width,(e.clientX-r.left)*source.width/r.width)),y:Math.max(0,Math.min(source.height,(e.clientY-r.top)*source.height/r.height))};}
    canvas.onpointerdown=e=>{start=point(e);canvas.setPointerCapture(e.pointerId);};
    canvas.onpointermove=e=>{if(!start)return;const end=point(e);selection={x:Math.min(start.x,end.x),y:Math.min(start.y,end.y),w:Math.abs(end.x-start.x),h:Math.abs(end.y-start.y)};redraw();};
    canvas.onpointerup=()=>{start=null;};canvas.onpointercancel=()=>{start=null;};
    let cancelled=false, activeWorker;
    const close=()=>{overlay.remove();URL.revokeObjectURL(url);};
    button('取消',()=>{cancelled=true;void activeWorker?.terminate();close();finish({cancelled:true});});
    button('轉正相片 ↻',()=>{const rotated=document.createElement('canvas');rotated.width=source.height;rotated.height=source.width;const ctx=rotated.getContext('2d');ctx.translate(rotated.width,0);ctx.rotate(Math.PI/2);ctx.drawImage(source,0,0);source=rotated;selection={x:0,y:0,w:source.width,h:source.height};redraw();});
    button('重新框選全張',()=>{selection={x:0,y:0,w:source.width,h:source.height};redraw();});
    const scan=button('辨識框內生字',async()=> {
      if(selection.w<20||selection.h<20){status.textContent='請框選大一點的生字範圍。';return;}
      scan.disabled=true;status.textContent='載入辨識引擎…';let worker;
      try {
        const Tesseract=await loadOCR();if(cancelled)return;const cropped=document.createElement('canvas');const scale=Math.min(3,2400/selection.w,3200/selection.h);cropped.width=Math.round(selection.w*scale);cropped.height=Math.round(selection.h*scale);
        const ctx=cropped.getContext('2d');ctx.fillStyle='white';ctx.fillRect(0,0,cropped.width,cropped.height);ctx.drawImage(source,selection.x,selection.y,selection.w,selection.h,0,0,cropped.width,cropped.height);
        const pixels=ctx.getImageData(0,0,cropped.width,cropped.height);for(let i=0;i<pixels.data.length;i+=4){const gray=.299*pixels.data[i]+.587*pixels.data[i+1]+.114*pixels.data[i+2];const contrast=Math.max(0,Math.min(255,(gray-128)*1.25+128));pixels.data[i]=pixels.data[i+1]=pixels.data[i+2]=contrast;}ctx.putImageData(pixels,0,0);
        worker=await Tesseract.createWorker('eng',1,{logger:m=>{if(m.status==='recognizing text')status.textContent=`辨識中 ${Math.round(m.progress*100)}%`;}});
        activeWorker=worker;if(cancelled){await worker.terminate();return;}
        await worker.setParameters({tessedit_pageseg_mode:'6',preserve_interword_spaces:'1'});
        const result=await worker.recognize(cropped);if(cancelled)return;close();finish({text:result.data.text,confidence:result.data.confidence});
      } catch(error){status.textContent=error.message||'辨識未完成，請重新裁切或改用清晰相片。';}
      finally{scan.disabled=false;await worker?.terminate();}
    });
    overlay.append(title,help,canvas,controls,status);document.body.append(overlay);redraw();
  }
})();

window.gardenOpenSpeechLab = () => { window.location.assign(new URL("speech-lab.html", document.baseURI).href); };
